package selenium;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChromedriverTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver","D:/indhu/m4/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.opencart.com/");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Test
	public void test() {

		 String expectedtitle = "Your Store";
		 WebDriver driver=new ChromeDriver();
	 driver.get("https://demo.opencart.com/");
	
		String  actualtitle = driver.getTitle();
		System.out.println(actualtitle);
		if (actualtitle.contentEquals(expectedtitle)) {
			System.out.println("Title Test Passed");

		} else {
			System.out.println("Title Test failed");
		}
	        assertEquals(expectedtitle, actualtitle);
	}
	}


