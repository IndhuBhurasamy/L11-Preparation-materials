package selenium;

import java.net.MalformedURLException;
import java.net.URL;
//import java.util.concurrent.TimeUnit;


import java.util.List;

import org.openqa.selenium.By;
//import org.openqa.selenium.Alert;
//import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
//import org.openqa.selenium.support.ui.Select;


public class Chrome {
	public static void main(String[] args) throws InterruptedException, MalformedURLException 

	{
		System.setProperty("webdriver.chromedriver.driver", "D:/Indhu/m4/chromedriver.exe");
	
		   
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setBrowserName("chrome");
		capabilities.setCapability("webdriver.chromedriver.driver", "D:/Indhu/m4/chromedriver.exe");
		

		
		capabilities.setPlatform(Platform.WINDOWS);
		//capabilities.setVersion(version);
		WebDriver driver = new RemoteWebDriver(new URL("http://localhost:6666/wd/hub"), capabilities);
		driver.get("https://demo.opencart.com/");
		String actualTitle = driver.getTitle();
		String expectedTitle = "Your Store";
		if(expectedTitle.equals(actualTitle))
		{
			System.out.println("Title matched");
		}
		else
		{
			System.out.println("Title does not match");
		}
		//Thread.sleep(10000);
		java.util.List<WebElement> links=driver.findElements(By.tagName("a"));
		if(links.size()==73)
		{
			System.out.println("verification of links is verified...It is passed...");
		}
		else
		{
			System.out.println("verification of links is not verified...It is failed...");
		}
		driver.findElement(By.className("caret")).click();
		System.out.println("My Account has been selected");
		
		driver.findElement(By.linkText("Register")).click();
		System.out.println("Register has been selected");
		
		//Thread.sleep(10000);
		driver.findElement(By.id("input-firstname")).sendKeys("Indhu");
		System.out.println("First name successfully entered..!!!");
		
		//Thread.sleep(10000);
		driver.findElement(By.xpath(".//*[@id='input-lastname']")).sendKeys("Bhurasamy");
		System.out.println("Last name successfully entered..!!!");
		
		//Thread.sleep(10000);
		WebElement e1 = driver.findElement(By.name("email"));
		e1.sendKeys("indhu@gmail.com");
		String email1 = e1.getText();
		String regex = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		System.out.println("Email id successfully entered..!!!");
		
		
		//Thread.sleep(10000);
		driver.findElement(By.cssSelector("#input-telephone")).sendKeys("7373835206");
		System.out.println("Mobile number successfully entered..!!!");
		
		WebElement p1 = driver.findElement(By.id("input-password"));
		p1.sendKeys("indhu");
		WebElement p2 = driver.findElement(By.name("confirm"));
		p2.sendKeys("indhu");
		String password1 = p1.getText();
		String password2 = p2.getText();
		if(password1.equals(password2))
		{
			System.out.println("password matched");
		}
		else
		{
			System.out.println("password does not match");
		}
		
		//Thread.sleep(10000);
		System.out.println("Passwords are successfully entered and successfully verified too..!!!");
		List oRadioButton = driver.findElements(By.name("newsletter"));
		// Create a boolean variable which will hold the value (True/False)
		boolean bValue = false;
		System.out.println("Radio button is successfully selected..!!!");
		boolean b= driver.getPageSource().contains("Subscribe");
		if(b == true)
		{
			System.out.println("Subscribe radio button is present");
		}
		else
		{
			System.out.println("Subscribe radio button is not present");
		}
		
		//Thread.sleep(10000);
	    driver.findElement(By.name("agree")).click();
	    System.out.println(" Privacy policies are agreed..!!!");
	    
	    //Thread.sleep(10000);
	    driver.findElement(By.cssSelector(".btn.btn-primary")).click();
	    System.out.println("Continue is successfully selected..!!!");
	    Thread.sleep(100);
	    String actualTitle1 = driver.getTitle();
		String expectedTitle1 = "Your Account Has Been Created!";
		if(expectedTitle1.equals(actualTitle1))
		{
			System.out.println("Title is matched");
		}
		else
		{
			System.out.println("Title does not match");
		}
		driver.findElement(By.xpath(".//*[@id='menu']/div[2]/ul/li[6]/a")).click();
		driver.findElement(By.xpath(".//*[@id='content']/div[2]/div[1]/div/div[1]/a/img")).click();
		boolean b1= driver.getPageSource().contains("HTC Touch HD");
		if(b1 == true)
		{
			System.out.println("HTC Touch HD text is present");
		}
		else
		{
			System.out.println("HTC Touch HD text is not present");
		}
		driver.navigate().back();
		driver.findElement(By.cssSelector(".button-group>button")).click();
		if(driver.getPageSource().contains("Success: You have added HTC Touch HD to your shopping cart!"))
		{
			System.out.println("Success message is verified");
		}
		else
		{
			System.out.println("Success message is not verified");
		}
		driver.findElement(By.linkText("Brands")).click();
		if(driver.getPageSource().contains("Find Your Favorite Brand"))
		{
			System.out.println("Find Your Favorite Brand text is verified,Passed");
		}
		else
		{
			System.out.println("Find Your Favorite Brand text is not verified,Failed");
		}
		driver.findElement(By.xpath(".//*[@id='content']/div[2]/div/a")).click();
		if(driver.getPageSource().contains("Canon"))
		{
			System.out.println("Canon text is verified,Passed");
		}
		else
		{
			System.out.println("Canon text is not verified,Failed");
		}
		driver.findElement(By.xpath(".//*[@id='content']/div[2]/div/div/div[2]/div[2]/button[2]")).click();
		if(driver.getPageSource().contains("Success: You have added Canon EOS 5D to your wish list!"))
		{
			System.out.println("Success: You have added Canon EOS 5D to your wish list! message is verified,Passed");
		}
		else
		{
			System.out.println("Success: You have added Canon EOS 5D to your wish list! message is not verified,Failed");
		}
		driver.findElement(By.xpath(".//*[@id='wishlist-total']")).click();
		if(driver.getPageSource().contains("My Wish List"))
		{
			System.out.println("My Wish List text is verified,Passed");
		}
		else
		{
			System.out.println("My Wish List text is not verified,Failed");
		}
		driver.close();
	}
	
}
