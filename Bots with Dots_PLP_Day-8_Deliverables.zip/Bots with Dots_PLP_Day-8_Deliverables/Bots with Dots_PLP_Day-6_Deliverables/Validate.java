package ishu;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validate {
	public static boolean Validatequantity(String qty){
		
		if(Pattern.matches("[0-9]{1,}",qty)){
			return true;
		}
		else{
			System.out.println("The quantity should not contain alphanumeric and special characters");
			return false;
		}
		
}

public static boolean Validatecopoun(String copoun){
	
	if(copoun.startsWith("PQRS")){
		return true;
	}
	else{
		System.out.println("The copoun code should match the pattern");
		return false;
	}
	
}
public static boolean Validatepost(String post){
	
	if(Pattern.matches("[0-9]{6}",post)){
		return true;
	}
	else{
		System.out.println("The postal code should match the pattern");
		return false;
	}
	
}
public static boolean Validategift(String gift){
	
	if(Pattern.matches("[A-Za-z]{4}[0-9]{4}",gift)){
		return true;
	}
	else{
		System.out.println("The postal code should match the pattern");
		return false;
	}
	
}
}
