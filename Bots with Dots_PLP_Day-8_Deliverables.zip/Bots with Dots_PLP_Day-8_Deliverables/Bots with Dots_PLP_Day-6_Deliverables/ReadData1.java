import ishu.Validate;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ReadData1 {

	public static void main(String[] args) throws IOException, InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","C:/Users/natyam/Desktop/chromedriver.exe");
	
		File src=new File("C:\\Users\\natyam\\Documents\\Testdata3.xlsx");
		
		FileInputStream fis =new FileInputStream(src); 

		XSSFWorkbook wb=new XSSFWorkbook(fis);
		
		XSSFSheet sheet=wb.getSheetAt(0);
		
		int rowCount=sheet.getLastRowNum();
		
		System.out.println("Total no of rows:"+rowCount);
		for(int i=1;i<=rowCount;i++)
		{
			WebDriver driver =new ChromeDriver();
			driver.get("https://demo.opencart.com/");
			try
			{
			driver.manage().window().maximize();
			driver.findElement(By.linkText("My Account")).click();
			Thread.sleep(1000);
			System.out.println("My Account is clicked");
			
			driver.findElement(By.linkText("Login")).click();
			Thread.sleep(1000);
			System.out.println("Login is clicked");
			
			driver.findElement(By.name("email")).sendKeys("ishwarya3@gmail.com");
			Thread.sleep(1000);
			driver.findElement(By.name("password")).sendKeys("ishu123");
			Thread.sleep(1000);
			driver.findElement(By.xpath(".//*[@id='content']/div/div[2]/div/form/input")).click();
			Thread.sleep(1000);
			String search=sheet.getRow(i).getCell(0).getStringCellValue();
			driver.findElement(By.xpath(".//*[@id='search']/input")).sendKeys(search);
			Thread.sleep(500);
			//clicking the search button
			driver.findElement(By.xpath(".//*[@id='search']/span/button")).click();
			Thread.sleep(500);
			//clicking on the image button
			driver.findElement(By.xpath(".//*[@id='content']/div[3]/div/div/div[1]/a/img")).click();
			Thread.sleep(500);
			WebElement quantity = driver.findElement(By.name("quantity"));
			String qty = quantity.getAttribute("value");
			driver.findElement(By.xpath(".//*[@id='input-quantity']")).clear();
			
			String quan=sheet.getRow(i).getCell(1).getStringCellValue();
			driver.findElement(By.xpath(".//*[@id='input-quantity']")).sendKeys(quan);
			if(Validate.Validatequantity(qty))
			{
				driver.findElement(By.xpath(".//*[@id='button-cart']")).click();
				Thread.sleep(2000);
			}
			driver.findElement(By.xpath(".//*[@id='cart']/button")).click();
			Thread.sleep(4000);
			
			driver.findElement(By.xpath(".//*[@id='cart']/ul/li[2]/div/p/a[1]/strong")).click();
			System.out.println("View cart is clicked");
			
			driver.findElement(By.xpath(".//*[@id='accordion']/div[1]/div[1]/h4/a")).click();
			Thread.sleep(1000);
			
			String coupon=sheet.getRow(i).getCell(2).getStringCellValue();
			driver.findElement(By.name("coupon")).sendKeys(coupon);
			WebElement copoun = driver.findElement(By.name("coupon"));
			String ccopoun = copoun.getAttribute("value");
			if(Validate.Validatecopoun(ccopoun))
			{
				
				driver.findElement(By.xpath(".//*[@id='button-coupon']")).click();
				Thread.sleep(1000);
				driver.findElement(By.xpath(".//*[@id='accordion']/div[2]/div[1]/h4/a")).click();
				Thread.sleep(1000);
				
				Select country= new Select(driver.findElement(By.name("country_id")));
				country.selectByValue("99");	
				Thread.sleep(1000);
				Thread.sleep(1000);
				Select region=new Select(driver.findElement(By.id("input-zone")));
				region.selectByVisibleText("Andhra Pradesh");
				Thread.sleep(1000);
				
				String post1=sheet.getRow(i).getCell(3).getStringCellValue();
				driver.findElement(By.id("input-postcode")).sendKeys(post1);
				WebElement post = driver.findElement(By.name("postcode"));
				String ppost = post.getAttribute("value");
				if(Validate.Validatepost(ppost))
				{
					
					driver.findElement(By.xpath(".//*[@id='button-quote']")).click();
					Thread.sleep(3000);
					
					driver.findElement(By.xpath(".//*[@id='modal-shipping']/div/div/div[2]/div/label")).click();
					Thread.sleep(1000);
					
					driver.findElement(By.xpath(".//*[@id='button-shipping']")).click();
					Thread.sleep(5000);
					
					driver.findElement(By.xpath(".//*[@id='accordion']/div[3]/div[1]/h4/a")).click();
					Thread.sleep(1000);
					
					String code=sheet.getRow(i).getCell(4).getStringCellValue();
					driver.findElement(By.id("input-voucher")).sendKeys(code);
					WebElement gift = driver.findElement(By.name("voucher"));
					String cgift = gift.getAttribute("value");
					if(Validate.Validategift(cgift))
					{
						driver.findElement(By.xpath(".//*[@id='button-voucher']")).click();
					}
				}
			}
			
			}
			 catch(NullPointerException e)
	       {
	           System.out.print("NullPointerException Caught");
	       }
		
	}
}
}	