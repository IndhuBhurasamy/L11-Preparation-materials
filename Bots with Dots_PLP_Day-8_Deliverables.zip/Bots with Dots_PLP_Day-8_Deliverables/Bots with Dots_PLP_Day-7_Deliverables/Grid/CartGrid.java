package ishu;

import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

public class CartGrid  {
		public static void main(String[] args) throws InterruptedException, MalformedURLException 

		{
			System.setProperty("webdriver.chrome.driver","C:/Users/natyam/Desktop/chromedriver.exe");
			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			capabilities.setBrowserName("chrome");
			capabilities.setCapability("webdriver.chrome.driver","C:/Users/natyam/Desktop/chromedriver.exe");			
			capabilities.setPlatform(Platform.WINDOWS);
			//capabilities.setVersion(version);
			WebDriver driver = new RemoteWebDriver(new URL("http://localhost:6666/wd/hub"), capabilities);
	try {
		Methods m=new Methods();
		driver.get("http://demo.opencart.com");	
		Thread.sleep(1000);
		//checking the titles are equal are not
		String actualTitle = driver.getTitle();
		String expectedTitle = "Your Store";
		m.stringEquals(actualTitle,expectedTitle);
		//clicking on Apple cinema 30
		driver.findElement(By.xpath("//*[@id='content']/div[2]/div[3]/div/div[2]/h4/a")).click();
		String title=driver.getTitle();
		//Title starts with
		m.stringStartsWith(title);
		//Title Ends with
		m.stringEndsWith(title);
		//clicking on the radio button
		driver.findElement(By.xpath("//*[@id='input-option218']/div[2]/label/input")).click();
		Thread.sleep(500);
		//clicking on checkbox
		driver.findElement(By.xpath("//*[@id='input-option223']/div[3]/label/input")).click();
		Thread.sleep(500);
		//clicking on check box
		driver.findElement(By.xpath("//*[@id='input-option223']/div[4]/label/input")).click();
		Thread.sleep(500);
		//clearing the data in the text box
		driver.findElement(By.xpath("//input[@name='option[208]']")).clear();
		//sending the data to the text box
		driver.findElement(By.xpath("//input[@name='option[208]']")).sendKeys("The Product Apple cinema 30");
		Thread.sleep(500);
		String text=driver.findElement(By.xpath("//input[@name='option[208]']")).getAttribute("value");
		//validating the text that contains only alphabets
		System.out.println("Does text ("+text+") contains only alphabets? "+m.stringContainsOnlyAlphabets(text));
		//selecting the colour
		Select colour=new Select(driver.findElement(By.name("option[217]")));
		colour.selectByValue("3");
		Thread.sleep(500);
		//sending the data to the text area
		driver.findElement(By.name("option[209]")).sendKeys("Product will be exchanged or not");
		Thread.sleep(500);
		String textArea=driver.findElement(By.id("input-option209")).getAttribute("value");
		//validating  the text area that contains with text
		m.stringContainsWith(textArea,text);
		//validating the text area that contains uppercase
		System.out.println("Does textarea ("+textArea+") contains any UpperCase? "+m.stringContainsUpperCase(textArea));
		//clearing the data in date
		driver.findElement(By.xpath(".//*[@id='input-option219']")).clear();
		//sending the data in date field
		driver.findElement(By.xpath(".//*[@id='input-option219']")).sendKeys("2018-07-28");
		Thread.sleep(500);
		//clearing the data in time
		driver.findElement(By.xpath(".//*[@id='input-option221']")).clear();
		//sending the data in time field
		driver.findElement(By.xpath(".//*[@id='input-option221']")).sendKeys("2:07");
		Thread.sleep(500);
		//clearing the data in date and time
		driver.findElement(By.xpath(".//*[@id='input-option220']")).clear();
		//sending the data in date and time
		driver.findElement(By.xpath(".//*[@id='input-option220']")).sendKeys("2018-07-28 2:07");
		Thread.sleep(500);
		//clearing the data in quantity
		driver.findElement(By.name("quantity")).clear();
		//sending the data in quantity
		driver.findElement(By.name("quantity")).sendKeys("3");
		Thread.sleep(500);
		String number=driver.findElement(By.name("quantity")).getAttribute("value");
		//validating the quantity that contains only numbers
		System.out.println("Does quantity ("+number+") contains only numbers? "+m.stringContainsOnlyNumbers(number));
		//clicking on the add to cart button
		driver.findElement(By.xpath(".//*[@id='button-cart']")).click();
		//sending the data in search field
		driver.findElement(By.name("search")).sendKeys("iMac");
		Thread.sleep(500);
		//clicking the search button
		driver.findElement(By.xpath(".//*[@id='search']/span/button")).click();
		Thread.sleep(500);
		//clicking on the image button
		driver.findElement(By.xpath(".//*[@id='content']/div[3]/div/div/div[1]/a/img")).click();
		Thread.sleep(500);
		//clicking on the add to cart
		driver.findElement(By.xpath(".//*[@id='button-cart']")).click();
		Thread.sleep(500);
		//clicking on the cart
		driver.findElement(By.xpath(".//*[@id='cart']/button")).click();
		Thread.sleep(500);
		//clicking on the view cart
		driver.findElement(By.xpath(".//*[@id='cart']/ul/li[2]/div/p/a[1]/strong")).click();
		Thread.sleep(1500);
		//clicking on use coupun code
		driver.findElement(By.xpath(".//*[@id='accordion']/div[1]/div[1]/h4/a/i")).click();
	    Thread.sleep(500);
	    //sending the data to the coupon code
	    driver.findElement(By.xpath(".//*[@id='input-coupon']")).sendKeys("123abc");
	    Thread.sleep(500);
	    //clicking on apply coupon
	    driver.findElement(By.xpath(".//*[@id='button-coupon']")).click();
	    Thread.sleep(500);
	    String coupon=driver.findElement(By.xpath(".//*[@id='input-coupon']")).getAttribute("value");
	    //validating the coupon that contains special characters
	    System.out.println("Does coupon ("+coupon+") contains Special Characters? "+m.stringContainsSpecialCharacters(coupon));
	    //clicking on estimate shipping and taxes button
		driver.findElement(By.xpath(".//*[@id='accordion']/div[2]/div[1]/h4/a/i")).click();
		Thread.sleep(500);
		//selecting the country
		Select country=new Select(driver.findElement(By.name("country_id")));
		country.selectByVisibleText("India");
	    Thread.sleep(1500);
	    //selecting the state
		Select state=new Select(driver.findElement(By.id("input-zone")));
		state.selectByVisibleText("Assam");
		Thread.sleep(500);
		//sending the data to the post code
		driver.findElement(By.xpath(".//*[@id='input-postcode']")).sendKeys("534324");
		Thread.sleep(500);
		//clicking on the use gift certificate button
		driver.findElement(By.xpath(".//*[@id='accordion']/div[3]/div[1]/h4/a")).click();
		Thread.sleep(500);
		//sending the data to the code
		driver.findElement(By.xpath(".//*[@id='input-voucher']")).sendKeys("55AE98");
		Thread.sleep(500);
		//clicking on the apply gift certificate button
		driver.findElement(By.xpath(".//*[@id='button-voucher']")).click();
		Thread.sleep(500);
		String code=driver.findElement(By.xpath(".//*[@id='input-voucher']")).getAttribute("value");
		//validating the code that contains aphanumeric
		System.out.println("Does code ("+code+") contains alphanumeric? "+ m.stringAlphaNumeric(code));
		driver.quit();
	}
	  catch(Exception ex){
		System.out.println("Hello");
	}
	
	
	}
}