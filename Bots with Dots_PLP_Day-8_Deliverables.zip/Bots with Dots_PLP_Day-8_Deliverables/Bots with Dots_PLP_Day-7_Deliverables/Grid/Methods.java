package ishu;

public class Methods {
			
		void stringStartsWith(String input)
		{
			if(input.length()==0)
			{
				System.out.println("String is empty");
			}
			else
			{
			 String index="";
			 index+=input.charAt(0);
			 System.out.println(input+" starts with: "+index);
			}
		}
		void stringEndsWith(String input)
		{
			if(input.length()==0)
			{
				System.out.println("String is empty");
			}
			else
			{
			 String index="";
			 index+=input.charAt(input.length()-1);
			 System.out.println(input+" ends with: "+index);
			}
		}
		void stringContainsWith(String actualstr,String substr)
		{
			boolean flag=false;
			if(actualstr.length()==0)
			{
				System.out.println("Actual String is empty");
				flag=true;
			}
			if(substr.length()==0)
			{
				System.out.println("Sub String is empty");
				flag=true;
			}			
			if(flag==false)
			{
				if(substr.length()>actualstr.length())
				{
					System.out.println("Actual String size is less than Sub String");
				}
				else
				{
				if(actualstr.contains(substr))
					System.out.println(actualstr+" contains "+substr);
				else
					System.out.println(actualstr+" does not contains "+substr);
				}
						
			}
		}		
		void stringEquals(String s1,String s2)
		{
			String msg=" you have entered is Invalid";
			boolean flag=false;
			if(s1.length()==0 || !s1.matches("[a-zA-Z ]+"))
			{
				if(s1.length()==0)
					System.out.println("String 1 is empty");
				else
					System.out.println("String 1"+msg + " "+ s1);
				flag=true;
			}
			if(s2.length()==0 || !s2.matches("[a-zA-Z ]+"))
			{
				if(s2.length()==0)
					System.out.println("String 2 is empty");
				else
				System.out.println("String 2"+msg + " "+ s2);
				flag=true;
			}	
			if(flag!=true)
				{
				if(s1.equals(s2))
					{
						System.out.println("Both strings("+s1+","+s2+") are equal.");
	        		} 
				else 
					{
						System.out.println("Both strings("+s1+","+s2+") are not equal.");
					}
				}
		}
		boolean stringAlphaNumeric(String input)
		{
		        if(input.matches("[a-zA-Z0-9 ]+"))
		        {
		        	return true;
		        }
		        else 
		        	return false;
		        
		}
		 boolean stringContainsOnlyAlphabets(String input) {
			 if(input.matches("[a-zA-Z ]+"))
		        {
		        	return true;
		        }
		        else 
		        	return false;
				
		 }
		 boolean stringContainsOnlyNumbers(String input)
		 {
			if((input.matches("[0-9]+")))
			{
				return true;
			}
			return false;
			 
		 }
		
		 boolean stringContainsUpperCase(String input)
		 {
			for(int i=0;i<input.length();i++)
			{
				if(Character.isUpperCase(input.charAt(i)))
				{
					return true;
				}
			}
			 return false;
		 }
		 boolean stringContainsSpecialCharacters(String input)
		 {
			if(!(input.matches("[a-zA-Z0-9 ]+")))
			{
				return true;
			}
			return false;
			 
		 }
		String toUpper(String input) {
			return toUpper(input);
		}
		public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
