package ishu;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CartJunit {
//	static chromeProfile profile = new chromeProfile();

	 WebDriver driver = new ChromeDriver(); 
	
	@BeforeClass
	public static void beforeclasstest()
	{
		
		System.setProperty("webdriver.chrome.driver","C:/Users/natyam/Desktop/chromedriver.exe");
	  }
	
	@Before
	public void beforetest()
	{
		System.out.println("Verification Starting.......");
	}
	
	
	@Test
	public void test() throws InterruptedException 
	{
		String expectedtitle = "Your Store";
	    driver.get("http://demo.opencart.com/");
		String  actualtitle = driver.getTitle();
		System.out.println(actualtitle);
		assertEquals(expectedtitle, actualtitle);

	
	@Test
	public void test1() throws InterruptedException 
	{
		//String expectedtitle = "Your Store";
	    driver.get("http://demo.opencart.com/");
		//sending the data in search field
		driver.findElement(By.name("search")).sendKeys("iMac");
		Thread.sleep(500);
		//clicking the search button
		driver.findElement(By.xpath(".//*[@id='search']/span/button")).click();
		Thread.sleep(500);
		//clicking on the image button
		driver.findElement(By.xpath(".//*[@id='content']/div[3]/div/div/div[1]/a/img")).click();
		Thread.sleep(500);
		//clearing the data in quantity
		driver.findElement(By.name("quantity")).clear();
		//sending the data in quantity
		driver.findElement(By.name("quantity")).sendKeys("3");
		Thread.sleep(500);
		//clicking on the add to cart
		driver.findElement(By.xpath(".//*[@id='button-cart']")).click();
	}
  @Test
	public void test2() throws InterruptedException 
	{
		boolean expectedtext =true;
	    driver.get("http://demo.opencart.com/");
	    boolean text1=driver.getPageSource().contains("Apple Cinema 30");
	    System.out.println(text1);
	    assertEquals(expectedtext, text1);
		
	}
	@After
	public void aftertest()
	{
		System.out.println("Verification ended");
		driver.close();
		
	}


}